#include <WiFi.h>
#include <ESP32Servo.h>  // Подключение библиотеки для работы с сервоприводом

// Настройки Wi-Fi
const char* ssid = "YOUR_WIFI_SSID";       // Название вашей сети
const char* password = "YOUR_WIFI_PASSWORD";  // Пароль вашей сети

// Номер порта для сервера
WiFiServer server(80);

// Состояние выходов
bool pumpState = false;  // Состояние насоса
bool windState = false;  // Состояние вентилятора
bool windowState = false;  // Состояние форточки

// Номера выводов
const int pumpPin = 17;  // Пин для насоса
const int windPin = 16;  // Пин для вентилятора
const int windowPin = 18;  // Пин для сервопривода (форточка)

// Объект для управления сервоприводом
Servo servoWindow;

// Прототипы функций
void handleRequest(WiFiClient& client, const String& request);
void sendResponse(WiFiClient& client);

void setup() {
    Serial.begin(115200);
    Serial.println("Starting...");

    // Инициализация библиотеки ESP32Servo
    ESP32Servo::init();

    // Настройка GPIO как выходы
    pinMode(pumpPin, OUTPUT);
    pinMode(windPin, OUTPUT);

    // Устанавливаем GPIO в LOW
    digitalWrite(pumpPin, LOW);
    digitalWrite(windPin, LOW);

    // Подключение к Wi-Fi
    Serial.print("Connecting to ");
    Serial.println(ssid);
    WiFi.begin(ssid, password);

    int connectionAttempts = 0;
    const int maxConnectionAttempts = 20; // Максимум 10 секунд ожидания

    while (WiFi.status() != WL_CONNECTED && connectionAttempts < maxConnectionAttempts) {
        delay(500);
        Serial.print(".");
        connectionAttempts++;
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("");
        Serial.println("WiFi connected.");
        Serial.println("IP address: ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println("");
        Serial.println("Failed to connect to WiFi.");
        return; // Выходим из setup(), если подключение не удалось
    }

    // Инициализация сервопривода
    servoWindow.attach(windowPin);  // Подключение сервопривода к пину 18
    servoWindow.write(0);           // Закрываем форточку по умолчанию

    // Запуск сервера
    server.begin();
}

void loop() {
    WiFiClient client = server.available();
    if (client) {
        Serial.println("New Client.");
        String currentLine = "";
        String request = "";

        while (client.connected()) {
            if (client.available()) {
                char c = client.read();
                Serial.write(c);
                request += c;

                if (c == '\n') {
                    if (currentLine.length() == 0) {
                        handleRequest(client, request);
                        request = "";
                        break;
                    } else {
                        currentLine = "";
                    }
                } else if (c != '\r') {
                    currentLine += c;
                }
            }
        }

        client.stop();
        Serial.println("Client disconnected.");
    }
}

void handleRequest(WiFiClient& client, const String& request) {
    // Обработка команд управления GPIO
    if (request.indexOf("/pump/on") != -1) {
        digitalWrite(pumpPin, HIGH);
        pumpState = true;
        Serial.println("Насос ВКЛ");
    } else if (request.indexOf("/pump/off") != -1) {
        digitalWrite(pumpPin, LOW);
        pumpState = false;
        Serial.println("Насос ВЫКЛ");
    } else if (request.indexOf("/wind/on") != -1) {
        digitalWrite(windPin, HIGH);
        windState = true;
        Serial.println("Вентилятор ВКЛ");
    } else if (request.indexOf("/wind/off") != -1) {
        digitalWrite(windPin, LOW);
        windState = false;
        Serial.println("Вентилятор ВЫКЛ");
    } else if (request.indexOf("/window/open") != -1) {
        servoWindow.write(90);  // Открываем форточку
        windowState = true;
        Serial.println("Форточка ОТКРЫТА");
    } else if (request.indexOf("/window/close") != -1) {
        servoWindow.write(0);  // Закрываем форточку
        windowState = false;
        Serial.println("Форточка ЗАКРЫТА");
    }

    // Отправка HTTP-ответа
    sendResponse(client);
}

void sendResponse(WiFiClient& client) {
    // Отправляем HTTP-заголовки
    client.println("HTTP/1.1 200 OK");
    client.println("Content-type:text/html");
    client.println("Connection: close");
    client.println();

    // Отправляем HTML-страницу
    client.println("<!DOCTYPE html>");
    client.println("<html lang=\"ru\">");
    client.println("<head>");
    client.println("<meta charset=\"UTF-8\">");
    client.println("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
    client.println("<title>Умная теплица</title>");
    client.println("<style>");
    client.println("body { font-family: Arial, sans-serif; background-color: #2b19a4; color: #ffffff; margin: 0; padding: 0; }");
    client.println(".container { max-width: 1200px; margin: 0 auto; padding: 20px; display: flex; flex-wrap: wrap; justify-content: space-between; }");
    client.println(".block-tab { display: flex; flex-wrap: wrap; width: 100%; }");
    client.println(".block-thin-tab { background-color: rgb(29, 134, 146); border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); margin: 10px; padding: 15px; width: calc(33.333% - 20px); box-sizing: auto; }");
    client.println(".switch input { display: none; }");
    client.println(".switch .slider { position: relative; display: inline-block; width: 60px; height: 34px; background-color: #ccc; border-radius: 34px; transition: background-color 0.3s; cursor: pointer; }");
    client.println(".switch .slider:before { content: ''; position: absolute; left: 4px; top: 4px; width: 26px; height: 26px; background-color: white; border-radius: 50%; transition: left 0.3s; }");
    client.println(".switch input:checked + .slider { background-color: #27ae60; }");
    client.println(".switch input:checked + .slider:before { left: 30px; }");
    client.println("</style>");
    client.println("</head>");
    client.println("<body>");
    client.println("<div class=\"container\">");
    client.println("<h1>Умная теплица</h1>");

    // Форточка
    client.println("<div class=\"block-thin-tab\">");
    client.println("<div class=\"switch-container\">");
    client.println("<label for=\"window-switch\">Форточка:</label>");
    client.println("<label class=\"switch\">");
    client.println(String("<input type=\"checkbox\" id=\"window-switch\" ") + (windowState ? "checked" : "") + ">"); // Добавляем состояние форточки
    client.println("<span class=\"slider round\"></span>");
    client.println("</label>");
    client.println("</div>");
    client.println("</div>");

    // JavaScript для обработки событий
    client.println("<script>");
    client.println("const windowSwitch = document.getElementById('window-switch');");
    client.println("windowSwitch.addEventListener('change', function() {");
    client.println("fetch(`/window/${this.checked ? 'open' : 'close'}`);");
    client.println("});");
    client.println("</script>");

    client.println("</div>");
    client.println("</body>");
    client.println("</html>");
}