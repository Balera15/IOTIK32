#include <WiFi.h>
#include <WebServer.h>
#include "page.h"

#define LED_RED 25
#define LED_GREEN 26

const char* ssid = "Galaxy S7";
const char* password = "jpav1663";

WebServer server(80);
 
const int led1Pin = LED_RED;
const int led2Pin = LED_GREEN;
int ledState = LOW;
int ledBrightness = 0;

void handleRoot() {
  server.send(200, "text/html", html);
}
 
void handleLED() {
  ledState = server.arg("state").toInt();
  digitalWrite(led1Pin, ledState);
  String txt = "{\"state\":" + String(ledState) + "}";
  server.send(200, "text/plain", txt);
  //server.send(200, "text/plain", String(ledState));
}
 
void handleBrightness() {
  ledBrightness = server.arg("value").toInt();
  analogWrite(led2Pin, ledBrightness);
  server.send(200, "text/plain", String(ledBrightness));
}

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  pinMode(led1Pin, OUTPUT);
  pinMode(led2Pin, OUTPUT);
  digitalWrite(led1Pin, ledState);
  analogWrite(led2Pin, ledBrightness);
  // WiFi Configuration & Init
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);
  Serial.print("Connecting To WiFi Network .");
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(100);
  }
  // Connected Successfully
  Serial.println("\nConnected To The WiFi Network");
  Serial.print("Local ESP32 IP: ");
  Serial.println(WiFi.localIP());
  // Attach Server Handler Functions & Start WebServer
  server.on("/", handleRoot);
  server.on("/led", handleLED);
  server.on("/brightness", handleBrightness);
  server.enableCORS();
  server.begin();
}

uint8_t dir = 1;

void loop() {
  // put your main code here, to run repeatedly:
  server.handleClient();
  // if(dir){
  //   digitalWrite(LED_RED, HIGH);
  //   digitalWrite(LED_GREEN, LOW);
  // }
  // else{
  //   digitalWrite(LED_RED, LOW);
  //   digitalWrite(LED_GREEN, HIGH);
  // }
  // dir ^= 1;
  // delay(300);
}